package com.mishen.st10250201_calculatorapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val num1 = findViewById<EditText>(R.id.Number1)
        val num2 = findViewById<EditText>(R.id.Number2)
        val additionBtn = findViewById<Button>(R.id.AddBtn)
        val subtBtn = findViewById<Button>(R.id.SubtractBtn)
        val multBtn = findViewById<Button>(R.id.MultiplyBtn)
        val divBtn = findViewById<Button>(
            R.id.DivideBtn
        )
        val resultTextView = findViewById<TextView>(R.id.resultTextView)
        additionBtn.setOnClickListener {
            val addnum1 = num1.text.toString().toInt()
            val addnum2 = num2.text.toString().toInt()
            val result = addnum1 + addnum2
            resultTextView.text = "$addnum1 + $addnum2 = $result"

        }
        multBtn.setOnClickListener {
            val multnum1 = num1.text.toString().toInt()
            val multnum2 = num2.text.toString().toInt()
            val resultmultiply = multnum1 * multnum2
            resultTextView.text = "$multnum1 x $multnum2 = $resultmultiply"
        }
        subtBtn.setOnClickListener {
            val subnum1 = num1.text.toString().toInt()
            val subnum2 = num2.text.toString().toInt()
            val resultsubtract = subnum1 - subnum2
            resultTextView.text = "$subnum1 - $subnum2 = $resultsubtract"
        }
        divBtn.setOnClickListener {
            val divnum1 = num1.text.toString().toInt()
            val divnum2 = num2.text.toString().toInt()
            if (divnum2 != 0) {
                val result = divnum1 / divnum2
                resultTextView.text = "$divnum1 / $divnum2 = $result"
            } else {
                resultTextView.text = "Division by zero is not allowed"
            }
        }

    }
}

